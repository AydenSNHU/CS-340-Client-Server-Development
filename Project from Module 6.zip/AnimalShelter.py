from pymongo import MongoClient
from bson.objectid import ObjectId

class AnimalShelter(object):
    #""" CRUD operations for Animal collection in MongoDB """

    def __init__(self, username, password):
        # Initializing the MongoClient. This helps to 
        # access the MongoDB databases and collections. 
        self.client = MongoClient('mongodb://%s:%s@localhost:43652' % (username, password))
        self.database = self.client['AAC']
        self.collection = self.database['animals']

# Complete this create method to implement the C in CRUD.
    def create(self, data):
        if data is not None:
            self.collection.insert_one(data)  # data should be dictionary
            return True
        else:
            raise Exception("Nothing to save, because data parameter is empty")
            return False

# Create method to implement the R in CRUD. 
    def read(self, search):
        if search is not None:
            result = self.collection.find(search)
            return result
        else:
            search = self.collection.find({})
            return data
        
# The method to implement the U in CRUD.
    def update(self, toUpdate, updateWith):
        try:
            result = self.collection.update_one(toUpdate, updateWith)
            return self.read(toUpdate)
        except Exception as e:
            return e
          
            
# The method to implement the D in CRUD.
    def delete(self, remove):
        try:
            result = self.database.animals.delete_one(remove)
            return self.read(remove)
        except Exception as e:
            return e